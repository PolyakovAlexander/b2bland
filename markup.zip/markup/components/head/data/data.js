head: {
    defaults: {
        title: 'default title',
        useSocialMetaTags: true;
    }
}